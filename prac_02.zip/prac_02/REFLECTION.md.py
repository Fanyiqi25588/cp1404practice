"So far, I have watched about 40% of the lecture videos, but I plan to keep progressing in the coming weeks and ensure I complete the remaining content."

"I watch lecture videos on weekdays in the evening for about 30 minutes to 1 hour, and on weekends, I watch for 1 hour each morning."

"What I am doing well in this course is staying organized, completing assignments on time, and managing my time effectively. I will continue to maintain these habits."

"What I need to stop or change is my tendency to procrastinate. I often start assignments at the last minute, which creates a lot of stress. From now on, I will make sure to start my work earlier instead of leaving it until the last moment."

"What I am doing poorly in practicals is time management. I sometimes waste time during tasks, which prevents me from completing them efficiently. I will focus more on planning my time and staying concentrated to finish tasks more efficiently."

"What I am doing well in practicals is collaborating with classmates and actively asking questions. When I encounter something I don't understand, I ask my peers or the instructor for clarification, which helps me better grasp the concepts and tasks. I will continue to do this."